README for the TIFF Creation Library
=====================================

This directory contains a library that can be used to create TIFF image
files.  This file was created for the purpose of supporting screen dumps
from an LCD.  Howeve, the logic is general and could be used for most
any purpose.

The only usage documentation is in the (rather extensive) comments in
the file apps/include/tiff.h

Unit Test
=========

See apps/examples/tiff
